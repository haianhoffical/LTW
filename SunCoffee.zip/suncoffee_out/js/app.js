/* ═══════════════════════════════════════════════
   SUN COFFEE PRO – Complete Management System
   Features: POS, Menu CRUD, Orders, Staff,
   Inventory, Stats, Invoices, QR Payment,
   Multi-language (VI/EN/ZH), Role-based Access
   ═══════════════════════════════════════════════ */

/* ── 1. i18n ── */
const I18N={
  vi:{
    dashboard:'Tổng quan',pos:'Gọi món (POS)',menu:'Quản lý thực đơn',
    orders:'Quản lý đơn hàng',invoices:'Tra cứu hóa đơn',staff:'Quản lý nhân viên',
    inventory:'Kho nguyên liệu',stats:'Thống kê doanh thu',
    logout:'Đăng xuất',login:'Đăng nhập',
    todayOrders:'Đơn hôm nay',todayRevenue:'Doanh thu hôm nay',
    weekRevenue:'Doanh thu 7 ngày',bestSeller:'Bán chạy nhất',
    recentOrders:'Đơn mới nhất',lowStockAlert:'⚠️ Nguyên liệu sắp hết',
    revenueChart:'Doanh thu 7 ngày gần đây',salesByCategory:'Theo danh mục',
    tableNo:'Số bàn',searchMenu:'Tìm món...',discount:'Giảm giá (đ)',
    subtotal:'Tạm tính',total:'Tổng cộng',pay:'Thanh toán',
    clearOrder:'Xóa đơn',newOrder:'Đơn mới',selectTable:'Chọn bàn',
    paymentTitle:'Thanh toán',paymentMethod:'Phương thức',
    cash:'Tiền mặt',momo:'Ví MoMo',bank:'Chuyển khoản',
    amountReceived:'Tiền khách đưa',change:'Tiền thừa',
    scanQR:'Quét mã QR để thanh toán',confirmPay:'Xác nhận đã nhận tiền',
    paySuccess:'Thanh toán thành công! 🎉',orderTotal:'Tổng đơn',
    orderId:'Mã đơn',items:'Món',status:'Trạng thái',payMethod:'TT',
    time:'Thời gian',action:'Thao tác',
    allStatus:'Tất cả',pending:'Chờ xử lý',preparing:'Đang pha',
    ready:'Sẵn sàng',completed:'Hoàn thành',cancelled:'Đã hủy',
    viewDetail:'Xem',updateStatus:'Cập nhật',
    productName:'Tên sản phẩm',price:'Giá (đ)',category:'Danh mục',
    description:'Mô tả',imageUrl:'URL hình ảnh',stock:'Tồn kho',
    hot:'Coffee Nóng',iced:'Coffee Đá',special:'Coffee Đặc Biệt',
    addProduct:'Thêm sản phẩm',editProduct:'Chỉnh sửa sản phẩm',
    staffName:'Họ và tên',phone:'Số điện thoại',email:'Email',
    role:'Vai trò',shift:'Ca làm',salary:'Lương (đ/tháng)',
    active:'Hoạt động',inactive:'Nghỉ việc',
    barista:'Pha chế (Barista)',cashier_r:'Thu ngân',waiter:'Phục vụ',
    morning:'Ca sáng (6:00–14:00)',afternoon:'Ca chiều (14:00–22:00)',
    addStaff:'Thêm nhân viên',
    ingredient:'Nguyên liệu',quantity:'Số lượng',unit:'Đơn vị',
    minQty:'Tối thiểu',costPrice:'Giá nhập',supplier:'Nhà cung cấp',
    addInventory:'Thêm nguyên liệu',adjustQty:'Điều chỉnh kho',
    totalOrders:'Tổng đơn',totalRevenue:'Tổng doanh thu',
    avgOrder:'Đơn trung bình',topProducts:'Top sản phẩm',
    searchInvoice:'Tìm mã đơn...',printInvoice:'In hóa đơn',
    invoiceTitle:'HÓA ĐƠN THANH TOÁN',
    add:'Thêm',edit:'Sửa',delete:'Xóa',save:'Lưu',cancel:'Hủy',
    search:'Tìm kiếm',all:'Tất cả',noData:'Không có dữ liệu',
    confirm:'Xác nhận',close:'Đóng',welcome:'Xin chào',
    username:'Tên đăng nhập',password:'Mật khẩu',
    loginBtnTxt:'Đăng nhập vào hệ thống',
    admin:'Quản trị viên',staffRole:'Nhân viên',cashierRole:'Thu ngân',
    note:'Ghi chú',table:'Bàn',pieces:'cái',kg:'kg',liter:'lít',box:'hộp',
    monthly:'Theo tháng',daily:'Theo ngày',
  },
  en:{
    dashboard:'Dashboard',pos:'POS (Order)',menu:'Menu Management',
    orders:'Order Management',invoices:'Invoice Lookup',staff:'Staff Management',
    inventory:'Inventory',stats:'Revenue Statistics',
    logout:'Logout',login:'Login',
    todayOrders:"Today's Orders",todayRevenue:"Today's Revenue",
    weekRevenue:'7-Day Revenue',bestSeller:'Best Seller',
    recentOrders:'Recent Orders',lowStockAlert:'⚠️ Low Stock Alert',
    revenueChart:'Revenue (Last 7 Days)',salesByCategory:'By Category',
    tableNo:'Table No.',searchMenu:'Search menu...',discount:'Discount (₫)',
    subtotal:'Subtotal',total:'Total',pay:'Pay Now',
    clearOrder:'Clear Order',newOrder:'New Order',selectTable:'Select Table',
    paymentTitle:'Payment',paymentMethod:'Method',
    cash:'Cash',momo:'MoMo Wallet',bank:'Bank Transfer',
    amountReceived:'Amount Received',change:'Change',
    scanQR:'Scan QR Code to Pay',confirmPay:'Confirm Payment',
    paySuccess:'Payment Successful! 🎉',orderTotal:'Order Total',
    orderId:'Order ID',items:'Items',status:'Status',payMethod:'Pay',
    time:'Time',action:'Action',
    allStatus:'All',pending:'Pending',preparing:'Preparing',
    ready:'Ready',completed:'Completed',cancelled:'Cancelled',
    viewDetail:'View',updateStatus:'Update',
    productName:'Product Name',price:'Price (₫)',category:'Category',
    description:'Description',imageUrl:'Image URL',stock:'Stock',
    hot:'Hot Coffee',iced:'Iced Coffee',special:'Special Coffee',
    addProduct:'Add Product',editProduct:'Edit Product',
    staffName:'Full Name',phone:'Phone',email:'Email',
    role:'Role',shift:'Shift',salary:'Salary (₫/mo)',
    active:'Active',inactive:'Inactive',
    barista:'Barista',cashier_r:'Cashier',waiter:'Waiter',
    morning:'Morning (6:00–14:00)',afternoon:'Afternoon (14:00–22:00)',
    addStaff:'Add Staff',
    ingredient:'Ingredient',quantity:'Quantity',unit:'Unit',
    minQty:'Min Qty',costPrice:'Cost Price',supplier:'Supplier',
    addInventory:'Add Ingredient',adjustQty:'Adjust Stock',
    totalOrders:'Total Orders',totalRevenue:'Total Revenue',
    avgOrder:'Avg Order',topProducts:'Top Products',
    searchInvoice:'Search order ID...',printInvoice:'Print Invoice',
    invoiceTitle:'PAYMENT RECEIPT',
    add:'Add',edit:'Edit',delete:'Delete',save:'Save',cancel:'Cancel',
    search:'Search',all:'All',noData:'No data found',
    confirm:'Confirm',close:'Close',welcome:'Welcome',
    username:'Username',password:'Password',
    loginBtnTxt:'Sign In to System',
    admin:'Administrator',staffRole:'Staff',cashierRole:'Cashier',
    note:'Note',table:'Table',pieces:'pcs',kg:'kg',liter:'L',box:'box',
    monthly:'Monthly',daily:'Daily',
  },
  zh:{
    dashboard:'概览',pos:'点单(POS)',menu:'菜单管理',
    orders:'订单管理',invoices:'发票查询',staff:'员工管理',
    inventory:'库存管理',stats:'营收统计',
    logout:'退出登录',login:'登录',
    todayOrders:'今日订单',todayRevenue:'今日营收',
    weekRevenue:'7天营收',bestSeller:'热销产品',
    recentOrders:'最新订单',lowStockAlert:'⚠️ 库存预警',
    revenueChart:'近7天营收',salesByCategory:'按类别',
    tableNo:'桌号',searchMenu:'搜索菜品...',discount:'折扣(₫)',
    subtotal:'小计',total:'合计',pay:'去结账',
    clearOrder:'清空',newOrder:'新订单',selectTable:'选择桌位',
    paymentTitle:'结账',paymentMethod:'支付方式',
    cash:'现金',momo:'MoMo钱包',bank:'银行转账',
    amountReceived:'收款金额',change:'找零',
    scanQR:'扫描二维码付款',confirmPay:'确认收款',
    paySuccess:'支付成功！🎉',orderTotal:'订单合计',
    orderId:'订单号',items:'餐品',status:'状态',payMethod:'支付',
    time:'时间',action:'操作',
    allStatus:'全部',pending:'待处理',preparing:'制作中',
    ready:'待取',completed:'已完成',cancelled:'已取消',
    viewDetail:'查看',updateStatus:'更新',
    productName:'产品名称',price:'价格(₫)',category:'类别',
    description:'描述',imageUrl:'图片URL',stock:'库存',
    hot:'热饮',iced:'冷饮',special:'特调',
    addProduct:'添加产品',editProduct:'编辑产品',
    staffName:'姓名',phone:'电话',email:'邮箱',
    role:'职位',shift:'班次',salary:'薪资(₫/月)',
    active:'在职',inactive:'离职',
    barista:'咖啡师',cashier_r:'收银员',waiter:'服务员',
    morning:'早班(6:00–14:00)',afternoon:'晚班(14:00–22:00)',
    addStaff:'添加员工',
    ingredient:'原料',quantity:'数量',unit:'单位',
    minQty:'最低库存',costPrice:'进价',supplier:'供应商',
    addInventory:'添加原料',adjustQty:'调整库存',
    totalOrders:'总订单',totalRevenue:'总营收',
    avgOrder:'平均订单',topProducts:'热销产品',
    searchInvoice:'搜索订单号...',printInvoice:'打印发票',
    invoiceTitle:'付款凭证',
    add:'添加',edit:'编辑',delete:'删除',save:'保存',cancel:'取消',
    search:'搜索',all:'全部',noData:'暂无数据',
    confirm:'确认',close:'关闭',welcome:'欢迎',
    username:'用户名',password:'密码',
    loginBtnTxt:'登录系统',
    admin:'管理员',staffRole:'员工',cashierRole:'收银员',
    note:'备注',table:'桌',pieces:'个',kg:'千克',liter:'升',box:'盒',
    monthly:'按月',daily:'按天',
  }
};
let lang='vi';
const t=k=>I18N[lang]?.[k]||I18N.vi?.[k]||k;
function setLang(l){lang=l;S.set('lang',l);document.querySelectorAll('.lang-btn').forEach(b=>b.classList.toggle('active',b.dataset.lang===l));refreshPage();}

/* ── 2. MOCK DATA ── */
const MOCK_PRODUCTS=[
  {id:1,name:'Cà Phê Đen',price:25000,category:'hot',categoryLabel:'Coffee Nóng',description:'Cà phê đen truyền thống đậm đà, pha từ hạt Robusta chọn lọc rang tươi.',image:'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=400&q=75',stock:50,rating:4.5,sold:120,featured:false},
  {id:2,name:'Cà Phê Sữa Nóng',price:30000,category:'hot',categoryLabel:'Coffee Nóng',description:'Kết hợp cà phê đậm và sữa đặc ngọt ngào đặc trưng Việt Nam.',image:'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=400&q=75',stock:45,rating:4.7,sold:250,featured:true},
  {id:3,name:'Cà Phê Đen Đá',price:25000,category:'iced',categoryLabel:'Coffee Đá',description:'Cà phê đen đá mát lạnh giải nhiệt, giữ trọn hương thơm đặc trưng.',image:'https://images.unsplash.com/photo-1517701604599-bb3a3d775518?w=400&q=75',stock:60,rating:4.6,sold:180,featured:false},
  {id:4,name:'Cà Phê Sữa Đá',price:35000,category:'iced',categoryLabel:'Coffee Đá',description:'Cà phê sữa đá kinh điển, thơm béo – thức uống không thể thiếu.',image:'https://images.unsplash.com/photo-1541167760496-1628856ab772?w=400&q=75',stock:55,rating:4.8,sold:350,featured:true},
  {id:5,name:'Bạc Xỉu',price:30000,category:'iced',categoryLabel:'Coffee Đá',description:'Đặc trưng Sài Gòn – nhẹ nhàng ngọt ngào với nhiều sữa béo.',image:'https://images.unsplash.com/photo-1572442388796-11668a67e53d?w=400&q=75',stock:40,rating:4.6,sold:200,featured:true},
  {id:6,name:'Cold Brew',price:45000,category:'special',categoryLabel:'Coffee Đặc Biệt',description:'Ủ lạnh 24 giờ với Arabica Ethiopia – mượt mà, ít chua, cafein cao.',image:'https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?w=400&q=75',stock:20,rating:4.9,sold:90,featured:true},
  {id:7,name:'Cappuccino',price:55000,category:'special',categoryLabel:'Coffee Đặc Biệt',description:'Phong cách Ý với foam sữa mềm mịn – espresso đậm, sữa bông xốp.',image:'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=400&q=75',stock:25,rating:4.7,sold:150,featured:false},
  {id:8,name:'Espresso',price:40000,category:'special',categoryLabel:'Coffee Đặc Biệt',description:'Shot cà phê cô đặc với crema vàng óng – đậm đà và tinh tế.',image:'https://images.unsplash.com/photo-1486511106655-c0c2fd6dd7a0?w=400&q=75',stock:30,rating:4.8,sold:110,featured:false},
];
const DEMO_ACCOUNTS=[
  {username:'admin',  password:'admin123',  name:'Trần Minh Admin', role:'admin',   email:'admin@suncoffee.vn'},
  {username:'staff',  password:'staff123',  name:'Nguyễn Văn An',   role:'staff',   email:'an@suncoffee.vn'},
  {username:'cashier',password:'cashier123',name:'Trần Thị Bảo',    role:'cashier', email:'bao@suncoffee.vn'},
];
const MOCK_STAFF=[
  {id:1,name:'Nguyễn Văn An',  phone:'0901234567',email:'an@suncoffee.vn',  role:'barista', shift:'morning',  salary:8000000,active:true, join:'2023-01-15'},
  {id:2,name:'Trần Thị Bảo',   phone:'0912345678',email:'bao@suncoffee.vn', role:'cashier', shift:'afternoon',salary:7500000,active:true, join:'2023-03-01'},
  {id:3,name:'Lê Minh Châu',   phone:'0923456789',email:'chau@suncoffee.vn',role:'waiter',  shift:'morning',  salary:7000000,active:true, join:'2023-06-15'},
  {id:4,name:'Phạm Thị Dung',  phone:'0934567890',email:'dung@suncoffee.vn',role:'barista', shift:'afternoon',salary:8500000,active:true, join:'2022-11-01'},
  {id:5,name:'Hoàng Văn Em',   phone:'0945678901',email:'em@suncoffee.vn',  role:'waiter',  shift:'morning',  salary:7000000,active:false,join:'2023-08-01'},
];
const MOCK_INVENTORY=[
  {id:1,name:'Cà phê Robusta', unit:'kg', quantity:12,minQty:5, cost:180000,supplier:'Vinacafe'},
  {id:2,name:'Cà phê Arabica', unit:'kg', quantity:3, minQty:5, cost:280000,supplier:'Trung Nguyên'},
  {id:3,name:'Sữa đặc Ông Thọ',unit:'hộp',quantity:48,minQty:10,cost:25000, supplier:'Vinamilk'},
  {id:4,name:'Sữa tươi',       unit:'lít',quantity:6, minQty:10,cost:28000, supplier:'Vinamilk'},
  {id:5,name:'Đường trắng',    unit:'kg', quantity:20,minQty:5, cost:22000, supplier:'Biên Hòa'},
  {id:6,name:'Đá viên',        unit:'kg', quantity:35,minQty:15,cost:3000,  supplier:'Địa phương'},
  {id:7,name:'Ly nhựa 500ml',  unit:'cái',quantity:200,minQty:100,cost:1500,supplier:'Bao bì Việt'},
  {id:8,name:'Ống hút',        unit:'cái',quantity:80,minQty:200,cost:200,  supplier:'Bao bì Việt'},
  {id:9,name:'Túi giấy',       unit:'cái',quantity:120,minQty:50,cost:3000, supplier:'In ấn ABC'},
  {id:10,name:'Nắp ly',        unit:'cái',quantity:180,minQty:100,cost:500, supplier:'Bao bì Việt'},
];
// Tạo 25 đơn hàng mẫu trong 7 ngày qua
function _genOrders(){
  const prds=MOCK_PRODUCTS;
  const stats=['completed','completed','completed','completed','preparing','pending','cancelled'];
  const pays=['cash','momo','bank'];
  const staffs=['Nguyễn Văn An','Trần Thị Bảo','Lê Minh Châu'];
  const orders=[];
  for(let i=1;i<=25;i++){
    const n=Math.floor(Math.random()*3)+1;
    const items=[];let sub=0;
    for(let j=0;j<n;j++){
      const p=prds[Math.floor(Math.random()*prds.length)];
      const q=Math.floor(Math.random()*3)+1;
      items.push({id:p.id,name:p.name,price:p.price,qty:q});
      sub+=p.price*q;
    }
    const disc=Math.random()>.75?Math.round(sub*.1/1000)*1000:0;
    const hrs=Math.random()*168;
    orders.push({
      id:`DH${String(i).padStart(3,'0')}`,
      table:Math.floor(Math.random()*12)+1,
      items,subtotal:sub,discount:disc,total:sub-disc,
      payment:pays[Math.floor(Math.random()*pays.length)],
      status:stats[Math.floor(Math.random()*stats.length)],
      staff:staffs[Math.floor(Math.random()*staffs.length)],
      note:'',
      time:new Date(Date.now()-hrs*3600000).toISOString()
    });
  }
  // Thêm 5 đơn trong hôm nay
  const todayItems=[[{id:4,name:'Cà Phê Sữa Đá',price:35000,qty:2},{id:6,name:'Cold Brew',price:45000,qty:1}],[{id:2,name:'Cà Phê Sữa Nóng',price:30000,qty:3}],[{id:7,name:'Cappuccino',price:55000,qty:1},{id:5,name:'Bạc Xỉu',price:30000,qty:2}],[{id:8,name:'Espresso',price:40000,qty:2}],[{id:4,name:'Cà Phê Sữa Đá',price:35000,qty:4}]];
  todayItems.forEach((items,i)=>{
    const sub=items.reduce((s,it)=>s+it.price*it.qty,0);
    orders.push({id:`DH${String(26+i).padStart(3,'0')}`,table:i+1,items,subtotal:sub,discount:0,total:sub,payment:pays[i%3],status:i<3?'completed':'preparing',staff:staffs[i%3],note:'',time:new Date(Date.now()-(i+1)*25*60000).toISOString()});
  });
  return orders.sort((a,b)=>new Date(b.time)-new Date(a.time));
}
const MOCK_ORDERS=_genOrders();

/* ── 3. LOCALSTORAGE ── */
const S={
  get:k=>{try{return JSON.parse(localStorage.getItem(k))}catch{return null}},
  set:(k,v)=>localStorage.setItem(k,JSON.stringify(v)),
  rm:k=>localStorage.removeItem(k)
};

/* ── 4. DATABASE ── */
const ProductDB={
  getAll:()=>{let d=S.get('sc_products');if(!d||!d.length){S.set('sc_products',MOCK_PRODUCTS);return[...MOCK_PRODUCTS]}return d},
  getById:id=>ProductDB.getAll().find(p=>p.id===parseInt(id)),
  add:p=>{const list=ProductDB.getAll();const n={...p,id:Date.now(),price:parseInt(p.price),stock:parseInt(p.stock||50),rating:4.0,sold:0,featured:false};list.push(n);S.set('sc_products',list);return n},
  update:(id,data)=>{const list=ProductDB.getAll();const i=list.findIndex(p=>p.id===parseInt(id));if(i!==-1){list[i]={...list[i],...data,price:parseInt(data.price),stock:parseInt(data.stock||list[i].stock)};S.set('sc_products',list);return list[i]}return null},
  delete:id=>{S.set('sc_products',ProductDB.getAll().filter(p=>p.id!==parseInt(id)))},
  reset:()=>S.set('sc_products',MOCK_PRODUCTS)
};
const OrderDB={
  getAll:()=>{let d=S.get('sc_orders');if(!d||!d.length){S.set('sc_orders',MOCK_ORDERS);return[...MOCK_ORDERS]}return d},
  getById:id=>OrderDB.getAll().find(o=>o.id===id),
  add:o=>{const list=OrderDB.getAll();list.unshift(o);S.set('sc_orders',list);return o},
  update:(id,data)=>{const list=OrderDB.getAll();const i=list.findIndex(o=>o.id===id);if(i!==-1){list[i]={...list[i],...data};S.set('sc_orders',list)}},
  getToday:()=>{const today=new Date().toDateString();return OrderDB.getAll().filter(o=>new Date(o.time).toDateString()===today)},
  getCompleted:()=>OrderDB.getAll().filter(o=>o.status==='completed')
};
const StaffDB={
  getAll:()=>{let d=S.get('sc_staff');if(!d||!d.length){S.set('sc_staff',MOCK_STAFF);return[...MOCK_STAFF]}return d},
  add:s=>{const list=StaffDB.getAll();const n={...s,id:Date.now(),active:true,join:new Date().toISOString().split('T')[0]};list.push(n);S.set('sc_staff',list);return n},
  update:(id,data)=>{const list=StaffDB.getAll();const i=list.findIndex(s=>s.id===parseInt(id));if(i!==-1){list[i]={...list[i],...data};S.set('sc_staff',list)}},
  delete:id=>{S.set('sc_staff',StaffDB.getAll().filter(s=>s.id!==parseInt(id)))}
};
const InventoryDB={
  getAll:()=>{let d=S.get('sc_inv');if(!d||!d.length){S.set('sc_inv',MOCK_INVENTORY);return[...MOCK_INVENTORY]}return d},
  add:item=>{const list=InventoryDB.getAll();const n={...item,id:Date.now(),quantity:parseInt(item.quantity),minQty:parseInt(item.minQty),cost:parseInt(item.cost)};list.push(n);S.set('sc_inv',list);return n},
  update:(id,data)=>{const list=InventoryDB.getAll();const i=list.findIndex(it=>it.id===parseInt(id));if(i!==-1){list[i]={...list[i],...data,quantity:parseInt(data.quantity),minQty:parseInt(data.minQty)};S.set('sc_inv',list)}},
  delete:id=>{S.set('sc_inv',InventoryDB.getAll().filter(it=>it.id!==parseInt(id)))}
};

/* ── 5. CART ── */
const Cart={
  get:()=>S.get('sc_cart')||[],
  add:(p,qty=1)=>{const c=Cart.get();const ex=c.find(i=>i.id===p.id);if(ex)ex.qty+=qty;else c.push({id:p.id,name:p.name,price:p.price,image:p.image,qty});S.set('sc_cart',c);Cart.badge()},
  setQty:(id,qty)=>{if(qty<=0){Cart.remove(id);return}const c=Cart.get();const it=c.find(i=>i.id===parseInt(id));if(it)it.qty=qty;S.set('sc_cart',c);Cart.badge()},
  remove:id=>{S.set('sc_cart',Cart.get().filter(i=>i.id!==parseInt(id)));Cart.badge()},
  clear:()=>{S.rm('sc_cart');Cart.badge()},
  total:()=>Cart.get().reduce((s,i)=>s+i.price*i.qty,0),
  count:()=>Cart.get().reduce((s,i)=>s+i.qty,0),
  badge:()=>{const n=Cart.count();const b=document.getElementById('cartBadge');if(b){b.textContent=n;b.style.display=n>0?'inline-flex':'none'}}
};

/* ── 6. AUTH ── */
const Auth={
  login:(u,p)=>{const acc=DEMO_ACCOUNTS.find(a=>a.username===u&&a.password===p);if(acc){S.set('sc_user',acc);return acc}return null},
  logout:()=>{S.rm('sc_user');showApp(false)},
  get:()=>S.get('sc_user'),
  is:()=>!!S.get('sc_user'),
  can:(pages)=>{const u=Auth.get();if(!u)return false;const perms={admin:['dashboard','pos','menu','orders','invoices','staff','inventory','stats'],staff:['pos','menu','orders'],cashier:['pos','orders','invoices']};return perms[u.role]?.includes(pages)||false}
};

/* ── 7. UTILS ── */
const V=n=>new Intl.NumberFormat('vi-VN',{style:'currency',currency:'VND'}).format(n);
const fmtDate=d=>{const dt=new Date(d);return dt.toLocaleDateString('vi-VN')};
const fmtTime=d=>{const dt=new Date(d);return dt.toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit'})};
const fmtDT=d=>fmtDate(d)+' '+fmtTime(d);

function showToast(msg,type='s'){
  document.querySelectorAll('.sun-toast').forEach(e=>e.remove());
  const icons={s:'✅',e:'❌',w:'⚠️',i:'ℹ️'};
  const el=document.createElement('div');
  el.className=`sun-toast ts-${type}`;
  el.innerHTML=`<span>${icons[type]||'✅'}</span><span>${msg}</span>`;
  document.body.appendChild(el);
  requestAnimationFrame(()=>el.classList.add('show'));
  setTimeout(()=>{el.classList.remove('show');setTimeout(()=>el.remove(),400)},3200);
}
function showModal(html){document.getElementById('modalBox').innerHTML=html;document.getElementById('modalOv').classList.remove('hidden')}
function closeModal(){document.getElementById('modalOv').classList.add('hidden')}
function tglPass(id,btn){const el=document.getElementById(id);const s=el.type==='password';el.type=s?'text':'password';btn.textContent=s?'🙈':'👁️'}
function sErr(id,msg){const el=document.getElementById(id),em=document.getElementById(id+'_e');if(el)el.classList.add('err');if(em){em.textContent=msg;em.classList.add('show')}}
function cErr(id){const el=document.getElementById(id),em=document.getElementById(id+'_e');if(el)el.classList.remove('err');if(em)em.classList.remove('show')}

/* ── 8. NAVIGATION ── */
let _curPage='dashboard';
const NAV_ITEMS=[
  {id:'dashboard',ico:'📊',admin:true,staff:false,cashier:false},
  {id:'pos',      ico:'🛒',admin:true,staff:true, cashier:true},
  {id:'menu',     ico:'☕',admin:true,staff:true, cashier:false},
  {id:'orders',   ico:'📋',admin:true,staff:true, cashier:true},
  {id:'invoices', ico:'🧾',admin:true,staff:false,cashier:true},
  {id:'staff',    ico:'👥',admin:true,staff:false,cashier:false},
  {id:'inventory',ico:'📦',admin:true,staff:false,cashier:false},
  {id:'stats',    ico:'📈',admin:true,staff:false,cashier:false},
];
function navigate(page){
  const user=Auth.get();
  if(!Auth.can(page)&&page!=='dashboard'){showToast('Bạn không có quyền truy cập trang này!','w');return}
  _curPage=page;
  window.location.hash=page;
  renderPage(page);
  updateNavActive(page);
  document.getElementById('topbarTitle').textContent=t(page);
  closeSidebar();
}
function refreshPage(){renderPage(_curPage);updateNavActive(_curPage);document.getElementById('topbarTitle').textContent=t(_curPage)}
function renderPage(page){
  const fn={dashboard:renderDashboard,pos:renderPOS,menu:renderMenu,orders:renderOrders,invoices:renderInvoices,staff:renderStaff,inventory:renderInventory,stats:renderStats};
  const main=document.getElementById('main');
  main.innerHTML=(fn[page]||renderDashboard)();
  window.scrollTo(0,0);
}
function updateNavActive(page){
  document.querySelectorAll('.sb-link[data-page]').forEach(a=>a.classList.toggle('active',a.dataset.page===page));
  document.querySelectorAll('.bn-item[data-page]').forEach(a=>a.classList.toggle('active',a.dataset.page===page));
}
function buildSidebar(){
  const user=Auth.get();if(!user)return;
  const nav=document.getElementById('sbNav');
  const bn=document.getElementById('bnInner');
  const items=NAV_ITEMS.filter(n=>n[user.role]);
  nav.innerHTML=items.map(n=>`<button class="sb-link" data-page="${n.id}" onclick="navigate('${n.id}')"><span class="ico">${n.ico}</span>${t(n.id)}</button>`).join('');
  bn.innerHTML=items.slice(0,5).map(n=>`<button class="bn-item" data-page="${n.id}" onclick="navigate('${n.id}')"><span class="ico">${n.ico}</span><span>${t(n.id).split(' ')[0]}</span></button>`).join('');
}
function buildTopbar(){
  const user=Auth.get();if(!user)return;
  const rl={admin:t('admin'),staff:t('staffRole'),cashier:t('cashierRole')};
  document.getElementById('tbAvatar').textContent=user.name[0];
  document.getElementById('tbName').textContent=user.name;
  document.getElementById('tbRole').textContent=rl[user.role]||user.role;
}
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open');document.getElementById('sbOverlay').classList.toggle('show')}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('sbOverlay').classList.remove('show')}
function showApp(show){
  document.getElementById('loginScreen').classList.toggle('hidden',show);
  document.getElementById('appLayout').classList.toggle('hidden',!show);
}
function handleLogout(){if(confirm(t('logout')+'?')){Auth.logout();showApp(false)}}

/* ── 9. DASHBOARD ── */
function renderDashboard(){
  const today=OrderDB.getToday();
  const todayComplete=today.filter(o=>o.status==='completed');
  const todayRev=todayComplete.reduce((s,o)=>s+o.total,0);
  const allOrders=OrderDB.getCompleted();
  const low=InventoryDB.getAll().filter(i=>i.quantity<=i.minQty);
  // Top sản phẩm
  const soldMap={};allOrders.forEach(o=>o.items.forEach(it=>{soldMap[it.name]=(soldMap[it.name]||0)+it.qty}));
  const top3=Object.entries(soldMap).sort((a,b)=>b[1]-a[1]).slice(0,3);
  const last7rev=getLast7Rev();
  return`
  <div class="ph"><h2>📊 ${t('dashboard')}</h2><p>${t('welcome')}, ${Auth.get()?.name}! Hôm nay ${fmtDate(new Date())}</p></div>
  <div class="stats-grid">
    <div class="stat-card"><div class="stat-ico">📋</div><div class="stat-val">${today.length}</div><div class="stat-lbl">${t('todayOrders')}</div><div class="stat-chg chg-up">✓ ${todayComplete.length} hoàn thành</div></div>
    <div class="stat-card"><div class="stat-ico">💰</div><div class="stat-val">${V(todayRev)}</div><div class="stat-lbl">${t('todayRevenue')}</div><div class="stat-chg chg-up">↑ +12% so với hôm qua</div></div>
    <div class="stat-card"><div class="stat-ico">☕</div><div class="stat-val">${top3[0]?top3[0][0].split(' ').slice(-2).join(' '):'–'}</div><div class="stat-lbl">${t('bestSeller')}</div><div class="stat-chg chg-up">${top3[0]?top3[0][1]+' ly':''}</div></div>
    <div class="stat-card"><div class="stat-ico">📦</div><div class="stat-val">${low.length}</div><div class="stat-lbl">Nguyên liệu sắp hết</div><div class="stat-chg ${low.length>0?'chg-dn':'chg-up'}">${low.length>0?'⚠️ Cần nhập thêm':'✅ Đủ hàng'}</div></div>
  </div>
  ${low.length>0?`<div class="inv-alert">${t('lowStockAlert')}: <b>${low.map(i=>i.name).join(', ')}</b> <button class="btn btn-sm btn-d" onclick="navigate('inventory')" style="margin-left:auto">Xem kho</button></div>`:''}
  <div class="chart-grid">
    <div class="chart-card"><h3>📈 ${t('revenueChart')}</h3><canvas id="revChart" height="200"></canvas></div>
    <div class="chart-card"><h3>🍩 ${t('salesByCategory')}</h3><canvas id="catChart" height="200"></canvas></div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
    <div class="card">
      <div class="card-hd"><h3>🕐 ${t('recentOrders')}</h3><button class="btn btn-sm btn-gh" onclick="navigate('orders')">${t('viewDetail')}</button></div>
      <div class="tbl-wrap"><table><thead><tr><th>${t('orderId')}</th><th>${t('table')}</th><th>${t('total')}</th><th>${t('status')}</th></tr></thead>
      <tbody>${OrderDB.getAll().slice(0,8).map(o=>`<tr><td class="fw7">${o.id}</td><td>Bàn ${o.table}</td><td class="fw8 cc">${V(o.total)}</td><td>${statusBadge(o.status)}</td></tr>`).join('')}</tbody>
      </table></div>
    </div>
    <div class="card">
      <div class="card-hd"><h3>🏆 ${t('topProducts')}</h3></div>
      <div class="card-body">
      ${Object.entries(soldMap).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([name,qty],i)=>`
        <div style="display:flex;align-items:center;gap:.75rem;margin-bottom:.75rem">
          <span style="width:24px;height:24px;border-radius:50%;background:${['var(--g)','#c0c0c0','#cd7f32','var(--bd)','var(--bd)','var(--bd)'][i]};display:flex;align-items:center;justify-content:center;font-size:.7rem;font-weight:800;color:${i<3?'var(--cdk)':'var(--mu)'}">${i+1}</span>
          <div style="flex:1"><div style="font-size:.82rem;font-weight:700;color:var(--cdk)">${name}</div>
          <div style="height:4px;background:var(--bd);border-radius:2px;margin-top:3px"><div style="height:100%;border-radius:2px;background:linear-gradient(to right,var(--c),var(--g));width:${Math.min(100,qty/top3[0]?.[1]*100||50)}%"></div></div></div>
          <span style="font-size:.78rem;font-weight:800;color:var(--c)">${qty} ly</span>
        </div>`).join('')}
      </div>
    </div>
  </div>`;
}
function getLast7Rev(){
  const orders=OrderDB.getCompleted();
  const days=[];const labels=[];
  for(let i=6;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);days.push(d.toDateString());labels.push(`${d.getDate()}/${d.getMonth()+1}`)}
  const values=days.map(d=>orders.filter(o=>new Date(o.time).toDateString()===d).reduce((s,o)=>s+o.total,0));
  return{labels,values};
}
function initCharts(){
  try{
    const r7=getLast7Rev();
    const orders=OrderDB.getCompleted();
    const catMap={};orders.forEach(o=>o.items.forEach(it=>{const p=ProductDB.getById(it.id);if(p)catMap[p.categoryLabel]=(catMap[p.categoryLabel]||0)+it.qty}));
    const rc=document.getElementById('revChart');
    if(rc&&typeof Chart!=='undefined'){
      new Chart(rc,{type:'line',data:{labels:r7.labels,datasets:[{label:'Doanh thu (đ)',data:r7.values,borderColor:'#6F4E37',backgroundColor:'rgba(111,78,55,.1)',fill:true,tension:.4,pointBackgroundColor:'#6F4E37'}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{callback:v=>V(v).replace('₫','').trim()}}}}});
    }
    const cc=document.getElementById('catChart');
    if(cc&&typeof Chart!=='undefined'){
      new Chart(cc,{type:'doughnut',data:{labels:Object.keys(catMap),datasets:[{data:Object.values(catMap),backgroundColor:['#6F4E37','#2980b9','#8e44ad'],borderWidth:2}]},options:{responsive:true,plugins:{legend:{position:'bottom'}}}});
    }
  }catch(e){console.log('Chart init:',e)}
}

/* ── 10. POS ── */
let _posCat='all',_posSearch='',_posDiscount=0,_posTable=1;
function renderPOS(){
  const products=ProductDB.getAll();
  const cart=Cart.get();
  const cartTotal=Cart.total();
  const finalTotal=Math.max(0,cartTotal-_posDiscount);
  return`
  <div class="ph d-flex jb ac fw gap2">
    <div><h2>🛒 ${t('pos')}</h2><p>Chọn món và tạo đơn hàng</p></div>
    <div class="d-flex gap1 fw ac">
      <label class="fl" style="margin:0">${t('tableNo')}:</label>
      <select class="fc" style="width:80px" onchange="_posTable=parseInt(this.value)" id="posTableSel">
        ${Array.from({length:15},(_,i)=>`<option value="${i+1}" ${_posTable===i+1?'selected':''}>Bàn ${i+1}</option>`).join('')}
      </select>
      <button class="btn btn-d btn-sm" onclick="clearPOS()">🗑️ ${t('clearOrder')}</button>
    </div>
  </div>
  <div class="pos-wrap">
    <!-- LEFT: Menu -->
    <div class="pos-menu-area">
      <div class="fb">
        <div class="sw"><span class="si">🔍</span><input class="si-inp" id="posSearch" placeholder="${t('searchMenu')}" oninput="filterPOS(this.value)"></div>
        <div class="d-flex gap1 fw">
          <button class="ftab${_posCat==='all'?' active':''}" onclick="setPOSCat('all',this)">${t('all')}</button>
          <button class="ftab${_posCat==='hot'?' active':''}" onclick="setPOSCat('hot',this)">🔥 ${t('hot')}</button>
          <button class="ftab${_posCat==='iced'?' active':''}" onclick="setPOSCat('iced',this)">🧊 ${t('iced')}</button>
          <button class="ftab${_posCat==='special'?' active':''}" onclick="setPOSCat('special',this)">⭐ ${t('special')}</button>
        </div>
      </div>
      <div class="menu-grid" id="menuGrid">
        ${renderMenuGrid(products)}
      </div>
    </div>
    <!-- RIGHT: Order -->
    <div class="pos-order">
      <div class="pos-hd">
        <div class="d-flex jb ac"><span class="fw7" style="font-size:.9rem">🛒 Đơn hàng – Bàn ${_posTable}</span><span class="cc fw8">${cart.length} món</span></div>
      </div>
      <div class="pos-items" id="posItems">
        ${cart.length?cart.map(it=>`
          <div class="pos-item">
            <div><div class="pi-name">${it.name}</div><div class="pi-price">${V(it.price)} × ${it.qty} = <b class="cc">${V(it.price*it.qty)}</b></div></div>
            <div class="pi-qty">
              <button class="pq-btn" onclick="posQty(${it.id},${it.qty-1})">−</button>
              <span class="pq-n">${it.qty}</span>
              <button class="pq-btn" onclick="posQty(${it.id},${it.qty+1})">+</button>
              <button class="pq-btn" style="border-color:var(--er);color:var(--er)" onclick="posQty(${it.id},0)">✕</button>
            </div>
          </div>`).join(''):`<div style="text-align:center;padding:2rem;color:var(--mu)"><div style="font-size:2.5rem;margin-bottom:.5rem">🛒</div><p style="font-size:.82rem">Chưa có món nào<br>Chọn từ menu bên trái</p></div>`}
      </div>
      <div class="pos-ft">
        <div class="tr-row"><span>${t('subtotal')}</span><span class="fw7">${V(cartTotal)}</span></div>
        <div class="tr-row" style="align-items:center">
          <span>${t('discount')}:</span>
          <input type="number" class="fc" style="width:120px;padding:.3rem .55rem;font-size:.8rem" value="${_posDiscount}" min="0" step="1000" onchange="_posDiscount=parseInt(this.value)||0;refreshPOSTotal()">
        </div>
        <div class="tr-total"><span>${t('total')}</span><span id="posFinalTotal">${V(finalTotal)}</span></div>
        <button class="btn btn-g btn-bl btn-lg" style="margin-top:.75rem" onclick="openPayment()" ${!cart.length?'disabled':''}>💳 ${t('pay')}</button>
      </div>
    </div>
  </div>`;
}
function renderMenuGrid(prds){
  let list=prds;
  if(_posCat!=='all')list=list.filter(p=>p.category===_posCat);
  if(_posSearch)list=list.filter(p=>p.name.toLowerCase().includes(_posSearch.toLowerCase()));
  if(!list.length)return`<div style="grid-column:1/-1;text-align:center;padding:2rem;color:var(--mu)">Không tìm thấy món</div>`;
  return list.map(p=>`<div class="mc${p.stock<=0?' mc-out':''}" onclick="addPOS(${p.id})"><img src="${p.image}" class="mc-img" onerror="this.src='https://placehold.co/150x100/6F4E37/FFD700?text=☕'"><div class="mc-body"><div class="mc-name">${p.name}</div><div class="mc-price">${V(p.price)}</div></div></div>`).join('');
}
function addPOS(id){const p=ProductDB.getById(id);if(p){Cart.add(p,1);refreshPOSOrder()}}
function posQty(id,qty){Cart.setQty(id,qty);refreshPOSOrder()}
function refreshPOSOrder(){
  const cart=Cart.get();const cartTotal=Cart.total();const finalTotal=Math.max(0,cartTotal-_posDiscount);
  const el=document.getElementById('posItems');
  if(el)el.innerHTML=cart.length?cart.map(it=>`<div class="pos-item"><div><div class="pi-name">${it.name}</div><div class="pi-price">${V(it.price)} × ${it.qty} = <b class="cc">${V(it.price*it.qty)}</b></div></div><div class="pi-qty"><button class="pq-btn" onclick="posQty(${it.id},${it.qty-1})">−</button><span class="pq-n">${it.qty}</span><button class="pq-btn" onclick="posQty(${it.id},${it.qty+1})">+</button><button class="pq-btn" style="border-color:var(--er);color:var(--er)" onclick="posQty(${it.id},0)">✕</button></div></div>`).join(''):`<div style="text-align:center;padding:2rem;color:var(--mu)"><div style="font-size:2.5rem">🛒</div><p style="font-size:.82rem">Chưa có món nào</p></div>`;
  const ft=document.getElementById('posFinalTotal');if(ft)ft.textContent=V(finalTotal);
}
function refreshPOSTotal(){const ft=document.getElementById('posFinalTotal');if(ft)ft.textContent=V(Math.max(0,Cart.total()-_posDiscount))}
function setPOSCat(cat,btn){_posCat=cat;document.querySelectorAll('.pos-menu-area .ftab').forEach(b=>b.classList.remove('active'));btn.classList.add('active');const g=document.getElementById('menuGrid');if(g)g.innerHTML=renderMenuGrid(ProductDB.getAll())}
let _pst;function filterPOS(v){_posSearch=v;clearTimeout(_pst);_pst=setTimeout(()=>{const g=document.getElementById('menuGrid');if(g)g.innerHTML=renderMenuGrid(ProductDB.getAll())},250)}
function clearPOS(){if(Cart.count()>0&&confirm('Xóa toàn bộ đơn hàng?')){Cart.clear();refreshPOSOrder()}}

/* ── 11. PAYMENT ── */
let _payMethod='cash',_payOrder=null;
function openPayment(){
  if(!Cart.count()){showToast('Giỏ hàng trống!','w');return}
  const total=Math.max(0,Cart.total()-_posDiscount);
  const orderId='DH'+Date.now().toString().slice(-6);
  _payOrder={id:orderId,table:_posTable,items:[...Cart.get()],subtotal:Cart.total(),discount:_posDiscount,total,payment:'cash',status:'preparing',staff:Auth.get()?.name||'–',note:'',time:new Date().toISOString()};
  _payMethod='cash';
  showModal(renderPayModal(total,orderId));
}
function renderPayModal(total,orderId){
  return`
  <div class="modal-hd"><h3>💳 ${t('paymentTitle')} – ${orderId}</h3><button class="modal-cl" onclick="closeModal()">✕</button></div>
  <div class="modal-body">
    <div style="background:var(--cr);border-radius:var(--rs);padding:.85rem 1rem;margin-bottom:1rem">
      <div style="font-size:.75rem;color:var(--mu);margin-bottom:.35rem">Tóm tắt đơn hàng – Bàn ${_posTable}</div>
      ${_payOrder.items.map(it=>`<div style="display:flex;justify-content:space-between;font-size:.82rem;padding:.2rem 0"><span>${it.name} ×${it.qty}</span><span class="fw7">${V(it.price*it.qty)}</span></div>`).join('')}
      <hr class="divider">
      <div style="display:flex;justify-content:space-between;font-size:1rem;font-weight:800;color:var(--cdk)"><span>${t('total')}</span><span class="cc">${V(total)}</span></div>
    </div>
    <div style="font-size:.8rem;font-weight:700;color:var(--cdk);margin-bottom:.6rem">${t('paymentMethod')}:</div>
    <div class="pay-methods">
      <div class="pm active" id="pm-cash" onclick="selectPayMethod('cash')"><div class="pm-ico">💵</div><div class="pm-lbl">${t('cash')}</div></div>
      <div class="pm" id="pm-momo" onclick="selectPayMethod('momo')"><div class="pm-ico">📱</div><div class="pm-lbl">${t('momo')}</div></div>
      <div class="pm" id="pm-bank" onclick="selectPayMethod('bank')"><div class="pm-ico">🏦</div><div class="pm-lbl">${t('bank')}</div></div>
    </div>
    <div id="payContent">${renderCashUI(total)}</div>
  </div>
  <div class="modal-ft">
    <button class="btn btn-gh" onclick="closeModal()">${t('cancel')}</button>
    <button class="btn btn-g btn-lg" id="confirmPayBtn" onclick="confirmPayment()">${t('confirmPay')}</button>
  </div>`;
}
function renderCashUI(total){
  return`<div class="cash-calc">
    <div class="cash-row"><label style="font-size:.82rem;font-weight:700">${t('amountReceived')}:</label></div>
    <input type="number" id="cashReceived" class="fc" placeholder="Nhập số tiền..." value="${total}" oninput="calcChange(${total})" step="1000" min="${total}">
    <div style="margin-top:.75rem;font-size:.8rem;color:var(--mu)">${t('change')}:</div>
    <div class="cash-change" id="cashChange">${V(0)}</div>
  </div>`;
}
function renderMoMoUI(total,orderId){
  setTimeout(()=>{try{if(typeof QRious!=='undefined'){new QRious({element:document.getElementById('momoQR'),value:`2|99|0909123456|SUN COFFEE|${total}|0|0|Thanh toan ${orderId}`,size:210,background:'white',foreground:'#ae2070'})}}catch(e){}},100);
  return`<div class="qr-wrap"><p style="font-size:.82rem;font-weight:700;color:var(--mu)">${t('scanQR')}</p><canvas id="momoQR" width="210" height="210" style="border-radius:var(--rs);border:1px solid var(--bd)"></canvas><div style="font-size:.78rem;color:var(--mu);text-align:center">SĐT MoMo: <b style="color:#ae2070">0909 123 456</b><br>Số tiền: <b class="cc">${V(total)}</b><br>Nội dung: <b>${orderId}</b></div></div>`;
}
function renderBankUI(total,orderId){
  const qrUrl=`https://img.vietqr.io/image/MB-0123456789-compact2.png?amount=${total}&addInfo=${encodeURIComponent('Thanh toan '+orderId)}&accountName=${encodeURIComponent('SUN COFFEE')}`;
  return`<div class="qr-wrap"><p style="font-size:.82rem;font-weight:700;color:var(--mu)">${t('scanQR')}</p><img src="${qrUrl}" class="qr-bank-img" onerror="this.src='https://placehold.co/210x210/6F4E37/FFD700?text=QR+Code'" alt="QR Code"><div style="font-size:.78rem;color:var(--mu);text-align:center">Ngân hàng: <b>MB Bank</b><br>STK: <b>0123456789</b><br>Tên: <b>SUN COFFEE</b><br>Số tiền: <b class="cc">${V(total)}</b></div></div>`;
}
function selectPayMethod(method){
  _payMethod=method;
  document.querySelectorAll('.pm').forEach(el=>el.classList.remove('active'));
  document.getElementById('pm-'+method)?.classList.add('active');
  if(!_payOrder)return;
  const total=_payOrder.total;const orderId=_payOrder.id;
  const pc=document.getElementById('payContent');
  if(pc){if(method==='cash')pc.innerHTML=renderCashUI(total);else if(method==='momo')pc.innerHTML=renderMoMoUI(total,orderId);else pc.innerHTML=renderBankUI(total,orderId)}
}
function calcChange(total){const r=parseInt(document.getElementById('cashReceived')?.value)||0;const c=document.getElementById('cashChange');if(c)c.textContent=V(Math.max(0,r-total))}
function confirmPayment(){
  if(!_payOrder)return;
  if(_payMethod==='cash'){const r=parseInt(document.getElementById('cashReceived')?.value)||0;if(r<_payOrder.total){showToast('Tiền nhận không đủ!','w');return}}
  const order={..._payOrder,payment:_payMethod,status:'completed'};
  OrderDB.add(order);Cart.clear();_posDiscount=0;
  closeModal();showToast(t('paySuccess'),'s');
  setTimeout(()=>navigate('pos'),800);
}

/* ── 12. MENU MANAGEMENT ── */
function renderMenu(){
  const products=ProductDB.getAll();
  const isAdmin=Auth.get()?.role==='admin';
  return`
  <div class="ph d-flex jb ac fw gap2">
    <div><h2>☕ ${t('menu')}</h2><p>${products.length} sản phẩm</p></div>
    ${isAdmin?`<button class="btn btn-p" onclick="openProductForm()">➕ ${t('addProduct')}</button>`:''}
  </div>
  <div class="fb">
    <div class="sw"><span class="si">🔍</span><input class="si-inp" placeholder="${t('search')}..." oninput="filterMenuTable(this.value)" id="menuSrch"></div>
    <div class="d-flex gap1 fw">
      <button class="ftab active" onclick="filterMenuCat('all',this)">${t('all')}</button>
      <button class="ftab" onclick="filterMenuCat('hot',this)">🔥 ${t('hot')}</button>
      <button class="ftab" onclick="filterMenuCat('iced',this)">🧊 ${t('iced')}</button>
      <button class="ftab" onclick="filterMenuCat('special',this)">⭐ ${t('special')}</button>
    </div>
  </div>
  <div class="card">
    <div class="tbl-wrap"><table id="menuTable"><thead><tr><th>Ảnh</th><th>${t('productName')}</th><th>${t('category')}</th><th>${t('price')}</th><th>Kho</th><th>Đã bán</th><th>★</th>${isAdmin?`<th>${t('action')}</th>`:''}</tr></thead>
    <tbody>${products.map(p=>`<tr><td><img src="${p.image}" class="td-img" onerror="this.src='https://placehold.co/38x38/6F4E37/FFD700?text=☕'"></td><td class="fw7">${p.name}<br><span style="font-size:.72rem;color:var(--mu)">${p.description.substring(0,50)}...</span></td><td>${catBadge(p.category)}</td><td class="fw8 cc">${V(p.price)}</td><td>${p.stock<=5?`<span class="badge b-low">${p.stock}</span>`:p.stock}</td><td>${p.sold}</td><td style="color:#e59400">★${p.rating}</td>${isAdmin?`<td><div class="d-flex gap1"><button class="btn btn-sm btn-gh" onclick="openProductForm(${p.id})">✏️</button><button class="btn btn-sm btn-d" onclick="delProduct(${p.id})">🗑️</button></div></td>`:''}</tr>`).join('')}</tbody>
    </table></div>
  </div>`;
}
function catBadge(cat){const m={hot:'<span class="badge b-pending">🔥 Nóng</span>',iced:'<span class="badge b-preparing">🧊 Đá</span>',special:'<span class="badge" style="background:rgba(142,68,173,.12);color:#6a1f9e">⭐ Đặc biệt</span>'};return m[cat]||cat}
let _menuCat='all';
function filterMenuCat(cat,btn){_menuCat=cat;document.querySelectorAll('#main .ftab').forEach(b=>b.classList.remove('active'));btn.classList.add('active');filterMenuTable(document.getElementById('menuSrch')?.value||'')}
function filterMenuTable(q){
  const rows=document.querySelectorAll('#menuTable tbody tr');
  rows.forEach(r=>{const name=r.cells[1]?.textContent.toLowerCase()||'';const cat=r.cells[2]?.textContent.toLowerCase()||'';const catOk=_menuCat==='all'||cat.includes({hot:'nóng',iced:'đá',special:'đặc'}[_menuCat]||_menuCat);r.style.display=(name.includes(q.toLowerCase())&&catOk)?'':'none'});
}
function openProductForm(id){
  const p=id?ProductDB.getById(id):null;
  showModal(`
  <div class="modal-hd"><h3>${p?t('editProduct'):t('addProduct')}</h3><button class="modal-cl" onclick="closeModal()">✕</button></div>
  <div class="modal-body">
    <form id="pForm">
    <div class="fr">
      <div class="fg"><label class="fl">${t('productName')} <span class="req">*</span></label><input id="pn" class="fc" value="${p?.name||''}" placeholder="Tên sản phẩm"><span class="em" id="pn_e"></span></div>
      <div class="fg"><label class="fl">${t('price')} <span class="req">*</span></label><input id="pp" type="number" class="fc" value="${p?.price||''}" placeholder="25000" min="1000"><span class="em" id="pp_e"></span></div>
    </div>
    <div class="fr">
      <div class="fg"><label class="fl">${t('category')} <span class="req">*</span></label><select id="pc" class="fc"><option value="">-- Chọn --</option><option value="hot" ${p?.category==='hot'?'selected':''}>🔥 ${t('hot')}</option><option value="iced" ${p?.category==='iced'?'selected':''}>🧊 ${t('iced')}</option><option value="special" ${p?.category==='special'?'selected':''}>⭐ ${t('special')}</option></select><span class="em" id="pc_e"></span></div>
      <div class="fg"><label class="fl">Tồn kho</label><input id="pst" type="number" class="fc" value="${p?.stock||50}" min="0"></div>
    </div>
    <div class="fg"><label class="fl">${t('description')}</label><textarea id="pd" class="fc">${p?.description||''}</textarea></div>
    <div class="fg"><label class="fl">${t('imageUrl')}</label><input id="pi" class="fc" value="${p?.image||''}" placeholder="https://..." oninput="document.getElementById('pImgPrev').src=this.value"></div>
    <img id="pImgPrev" src="${p?.image||''}" style="width:100%;max-height:140px;object-fit:cover;border-radius:var(--rs);margin-top:.5rem;${p?.image?'':'display:none'}" onerror="this.style.display='none'" onload="this.style.display='block'">
    </form>
  </div>
  <div class="modal-ft">
    <button class="btn btn-gh" onclick="closeModal()">${t('cancel')}</button>
    <button class="btn btn-p" onclick="saveProduct(${id||'null'})">${t('save')}</button>
  </div>`);
}
function saveProduct(id){
  const name=document.getElementById('pn').value.trim();
  const price=document.getElementById('pp').value;
  const cat=document.getElementById('pc').value;
  let ok=true;
  if(!name){sErr('pn','Tên không được để trống');ok=false}else cErr('pn');
  if(!price||parseInt(price)<=0){sErr('pp','Giá phải là số dương');ok=false}else cErr('pp');
  if(!cat){sErr('pc','Vui lòng chọn danh mục');ok=false}else cErr('pc');
  if(!ok)return;
  const catLabels={hot:'Coffee Nóng',iced:'Coffee Đá',special:'Coffee Đặc Biệt'};
  const data={name,price,category:cat,categoryLabel:catLabels[cat],description:document.getElementById('pd').value.trim(),image:document.getElementById('pi').value.trim()||'https://placehold.co/400x300/6F4E37/FFD700?text=☕',stock:document.getElementById('pst').value};
  if(id&&id!=='null')ProductDB.update(id,data);else ProductDB.add(data);
  closeModal();showToast(`✅ Đã ${id&&id!=='null'?'cập nhật':'thêm'} sản phẩm "${name}"!`,'s');
  navigate('menu');
}
function delProduct(id){const p=ProductDB.getById(id);if(p&&confirm(`Xóa "${p.name}"?`)){ProductDB.delete(id);showToast('Đã xóa sản phẩm!','s');navigate('menu')}}

/* ── 13. ORDERS ── */
let _ordCat='all',_ordSearch='';
function renderOrders(){
  const all=OrderDB.getAll();
  return`
  <div class="ph d-flex jb ac fw gap2">
    <div><h2>📋 ${t('orders')}</h2><p>${all.length} đơn hàng</p></div>
    <button class="btn btn-s btn-sm" onclick="navigate('pos')">➕ Tạo đơn mới</button>
  </div>
  <div class="fb">
    <div class="sw"><span class="si">🔍</span><input class="si-inp" placeholder="${t('searchInvoice')}" oninput="filterOrders(this.value)"></div>
    <div class="d-flex gap1 fw">
      ${['all','pending','preparing','ready','completed','cancelled'].map(s=>`<button class="ftab${_ordCat===s?' active':''}" onclick="setOrdCat('${s}',this)">${s==='all'?t('allStatus'):statusLabel(s)}</button>`).join('')}
    </div>
  </div>
  <div class="card">
    <div class="tbl-wrap">
    <table id="ordTable"><thead><tr><th>${t('orderId')}</th><th>Bàn</th><th>Món</th><th>${t('total')}</th><th>TT</th><th>${t('status')}</th><th>${t('time')}</th><th>${t('action')}</th></tr></thead>
    <tbody id="ordBody">${renderOrderRows(all)}</tbody>
    </table></div>
  </div>`;
}
function renderOrderRows(orders){
  let list=orders;
  if(_ordCat!=='all')list=list.filter(o=>o.status===_ordCat);
  if(_ordSearch)list=list.filter(o=>o.id.toLowerCase().includes(_ordSearch.toLowerCase())||o.table.toString().includes(_ordSearch));
  if(!list.length)return`<tr><td colspan="8" style="text-align:center;padding:2rem;color:var(--mu)">Không có đơn hàng</td></tr>`;
  return list.map(o=>`<tr><td class="fw8">${o.id}</td><td>Bàn ${o.table}</td><td style="font-size:.78rem">${o.items.map(it=>`${it.name}×${it.qty}`).join(', ')}</td><td class="fw8 cc">${V(o.total)}</td><td style="font-size:.75rem">${{cash:'💵',momo:'📱',bank:'🏦'}[o.payment]||'–'}</td><td>${statusBadge(o.status)}</td><td style="font-size:.75rem;color:var(--mu)">${fmtDT(o.time)}</td><td><div class="d-flex gap1"><button class="btn btn-sm btn-gh" onclick="viewOrder('${o.id}')">👁️</button>${o.status!=='completed'&&o.status!=='cancelled'?`<select class="fc" style="padding:.25rem .45rem;font-size:.72rem;border-radius:var(--rs)" onchange="updateOrderStatus('${o.id}',this.value)"><option value="">Đổi...</option><option value="preparing">Đang pha</option><option value="ready">Sẵn sàng</option><option value="completed">Hoàn thành</option><option value="cancelled">Hủy đơn</option></select>`:''}</div></td></tr>`).join('');
}
function filterOrders(q){_ordSearch=q;const tb=document.getElementById('ordBody');if(tb)tb.innerHTML=renderOrderRows(OrderDB.getAll())}
function setOrdCat(cat,btn){_ordCat=cat;document.querySelectorAll('#main .ftab').forEach(b=>b.classList.remove('active'));btn.classList.add('active');const tb=document.getElementById('ordBody');if(tb)tb.innerHTML=renderOrderRows(OrderDB.getAll())}
function updateOrderStatus(id,status){if(!status)return;OrderDB.update(id,{status});showToast('Đã cập nhật trạng thái!','s');const tb=document.getElementById('ordBody');if(tb)tb.innerHTML=renderOrderRows(OrderDB.getAll())}
function viewOrder(id){
  const o=OrderDB.getById(id);if(!o)return;
  showModal(`
  <div class="modal-hd"><h3>📋 Chi tiết đơn ${o.id}</h3><button class="modal-cl" onclick="closeModal()">✕</button></div>
  <div class="modal-body">
    <div class="inv-box">
      <div class="inv-hd"><h2>${t('invoiceTitle')}</h2><p style="font-size:.78rem;color:var(--mu)">☕ Sun Coffee – 123 Nguyễn Huệ, Q.1</p></div>
      <div class="inv-row"><span>${t('orderId')}</span><span class="fw7">${o.id}</span></div>
      <div class="inv-row"><span>Bàn</span><span class="fw7">${o.table}</span></div>
      <div class="inv-row"><span>Thời gian</span><span>${fmtDT(o.time)}</span></div>
      <div class="inv-row"><span>Nhân viên</span><span>${o.staff}</span></div>
      <hr class="divider">
      ${o.items.map(it=>`<div class="inv-row"><span>${it.name} × ${it.qty}</span><span class="fw7">${V(it.price*it.qty)}</span></div>`).join('')}
      <hr class="divider">
      <div class="inv-row"><span>${t('subtotal')}</span><span>${V(o.subtotal)}</span></div>
      ${o.discount?`<div class="inv-row cok"><span>Giảm giá</span><span>-${V(o.discount)}</span></div>`:''}
      <div class="inv-tot"><span>${t('total')}</span><span class="cc">${V(o.total)}</span></div>
      <div class="inv-row" style="margin-top:.4rem"><span>Phương thức</span><span>${{cash:'💵 Tiền mặt',momo:'📱 MoMo',bank:'🏦 Chuyển khoản'}[o.payment]}</span></div>
      <div class="inv-row"><span>Trạng thái</span><span>${statusBadge(o.status)}</span></div>
      <div class="inv-ft">☕ Sun Coffee – Cảm ơn quý khách!<br>📞 0909 123 456</div>
    </div>
  </div>
  <div class="modal-ft"><button class="btn btn-gh" onclick="closeModal()">${t('close')}</button><button class="btn btn-p" onclick="window.print()">🖨️ ${t('printInvoice')}</button></div>`);
}
function statusBadge(s){const m={pending:'b-pending',preparing:'b-preparing',ready:'b-ready',completed:'b-completed',cancelled:'b-cancelled'};return`<span class="badge ${m[s]||''}">${statusLabel(s)}</span>`}
function statusLabel(s){const m={all:'Tất cả',pending:'Chờ xử lý',preparing:'Đang pha',ready:'Sẵn sàng',completed:'Hoàn thành',cancelled:'Đã hủy'};return m[s]||s}

/* ── 14. INVOICES ── */
function renderInvoices(){
  const orders=OrderDB.getCompleted();
  return`
  <div class="ph"><h2>🧾 ${t('invoices')}</h2><p>${orders.length} hóa đơn đã thanh toán</p></div>
  <div class="fb">
    <div class="sw"><span class="si">🔍</span><input class="si-inp" placeholder="${t('searchInvoice')}" oninput="filterInvoices(this.value)" id="invSrch"></div>
    <div class="d-flex gap1 fw ac">
      <label style="font-size:.78rem;color:var(--mu)">Từ:</label>
      <input type="date" class="fc" id="invFrom" style="width:150px;padding:.4rem .65rem" onchange="filterInvoices()">
      <label style="font-size:.78rem;color:var(--mu)">Đến:</label>
      <input type="date" class="fc" id="invTo" style="width:150px;padding:.4rem .65rem" onchange="filterInvoices()">
    </div>
  </div>
  <div class="card">
    <div class="tbl-wrap"><table><thead><tr><th>Mã HĐ</th><th>Bàn</th><th>Món</th><th>TT</th><th>Tổng tiền</th><th>Thời gian</th><th>Thao tác</th></tr></thead>
    <tbody id="invBody">${renderInvoiceRows(orders)}</tbody></table></div>
  </div>`;
}
function renderInvoiceRows(orders){
  if(!orders.length)return`<tr><td colspan="7" style="text-align:center;padding:2rem;color:var(--mu)">Không có hóa đơn</td></tr>`;
  return orders.map(o=>`<tr><td class="fw8 cc">${o.id}</td><td>Bàn ${o.table}</td><td style="font-size:.78rem">${o.items.length} món</td><td>{{${o.payment}}}</td><td class="fw8 cc">${V(o.total)}</td><td style="font-size:.75rem;color:var(--mu)">${fmtDT(o.time)}</td><td><button class="btn btn-sm btn-gh" onclick="viewOrder('${o.id}')">👁️ Xem</button></td></tr>`.replace('{{cash}}','💵 Tiền mặt').replace('{{momo}}','📱 MoMo').replace('{{bank}}','🏦 Bank').replace(/\{\{(\w+)\}\}/,'$1')).join('');
}
function filterInvoices(q){
  const from=document.getElementById('invFrom')?.value;
  const to=document.getElementById('invTo')?.value;
  const search=q!==undefined?q:(document.getElementById('invSrch')?.value||'');
  let orders=OrderDB.getCompleted();
  if(search)orders=orders.filter(o=>o.id.toLowerCase().includes(search.toLowerCase()));
  if(from)orders=orders.filter(o=>new Date(o.time)>=new Date(from));
  if(to)orders=orders.filter(o=>new Date(o.time)<=new Date(to+'T23:59:59'));
  const tb=document.getElementById('invBody');
  if(tb)tb.innerHTML=renderInvoiceRows(orders);
}

/* ── 15. STAFF ── */
function renderStaff(){
  const staff=StaffDB.getAll();
  const roles={barista:t('barista'),cashier:t('cashier_r'),waiter:t('waiter')};
  const shifts={morning:t('morning'),afternoon:t('afternoon')};
  return`
  <div class="ph d-flex jb ac fw gap2">
    <div><h2>👥 ${t('staff')}</h2><p>${staff.filter(s=>s.active).length} nhân viên đang làm việc</p></div>
    <button class="btn btn-p" onclick="openStaffForm()">➕ ${t('addStaff')}</button>
  </div>
  <div class="stats-grid">
    <div class="stat-card"><div class="stat-ico">👨‍🍳</div><div class="stat-val">${staff.filter(s=>s.role==='barista'&&s.active).length}</div><div class="stat-lbl">Pha chế (Barista)</div></div>
    <div class="stat-card"><div class="stat-ico">💰</div><div class="stat-val">${staff.filter(s=>s.role==='cashier'&&s.active).length}</div><div class="stat-lbl">Thu ngân</div></div>
    <div class="stat-card"><div class="stat-ico">🫡</div><div class="stat-val">${staff.filter(s=>s.role==='waiter'&&s.active).length}</div><div class="stat-lbl">Phục vụ</div></div>
    <div class="stat-card"><div class="stat-ico">💵</div><div class="stat-val">${V(staff.filter(s=>s.active).reduce((s,e)=>s+parseInt(e.salary||0),0))}</div><div class="stat-lbl">Tổng lương/tháng</div></div>
  </div>
  <div class="card">
    <div class="tbl-wrap"><table><thead><tr><th>${t('staffName')}</th><th>${t('phone')}</th><th>${t('role')}</th><th>${t('shift')}</th><th>${t('salary')}</th><th>Ngày vào</th><th>Trạng thái</th><th>${t('action')}</th></tr></thead>
    <tbody>${staff.map(s=>`<tr><td><div class="d-flex gap1 ac"><div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--c),var(--cmd));display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:.85rem">${s.name[0]}</div><div><div class="fw7">${s.name}</div><div style="font-size:.72rem;color:var(--mu)">${s.email}</div></div></div></td><td>${s.phone}</td><td><span class="badge b-${s.role==='barista'?'completed':s.role==='cashier'?'cashier':'staff'}">${roles[s.role]||s.role}</span></td><td style="font-size:.78rem">${s.shift==='morning'?'☀️ Sáng':'🌙 Chiều'}</td><td class="fw7">${V(s.salary)}</td><td style="font-size:.75rem;color:var(--mu)">${fmtDate(s.join)}</td><td><span class="badge ${s.active?'b-ready':'b-cancelled'}">${s.active?t('active'):t('inactive')}</span></td><td><div class="d-flex gap1"><button class="btn btn-sm btn-gh" onclick="openStaffForm(${s.id})">✏️</button><button class="btn btn-sm btn-d" onclick="delStaff(${s.id})">🗑️</button></div></td></tr>`).join('')}
    </tbody></table></div>
  </div>`;
}
function openStaffForm(id){
  const s=id?StaffDB.getAll().find(x=>x.id===parseInt(id)):null;
  showModal(`
  <div class="modal-hd"><h3>${s?t('edit')+' nhân viên':'➕ '+t('addStaff')}</h3><button class="modal-cl" onclick="closeModal()">✕</button></div>
  <div class="modal-body">
    <div class="fr">
      <div class="fg"><label class="fl">${t('staffName')} <span class="req">*</span></label><input id="sn" class="fc" value="${s?.name||''}"><span class="em" id="sn_e"></span></div>
      <div class="fg"><label class="fl">${t('phone')}</label><input id="sp" class="fc" value="${s?.phone||''}"></div>
    </div>
    <div class="fg"><label class="fl">${t('email')}</label><input id="se" type="email" class="fc" value="${s?.email||''}"></div>
    <div class="fr">
      <div class="fg"><label class="fl">${t('role')}</label><select id="sr" class="fc"><option value="barista" ${s?.role==='barista'?'selected':''}>👨‍🍳 ${t('barista')}</option><option value="cashier" ${s?.role==='cashier'?'selected':''}>💰 ${t('cashier_r')}</option><option value="waiter" ${s?.role==='waiter'?'selected':''}>🫡 ${t('waiter')}</option></select></div>
      <div class="fg"><label class="fl">${t('shift')}</label><select id="ss" class="fc"><option value="morning" ${s?.shift==='morning'?'selected':''}>☀️ ${t('morning')}</option><option value="afternoon" ${s?.shift==='afternoon'?'selected':''}>🌙 ${t('afternoon')}</option></select></div>
    </div>
    <div class="fr">
      <div class="fg"><label class="fl">${t('salary')} (đ)</label><input id="sal" type="number" class="fc" value="${s?.salary||7000000}" step="500000"></div>
      <div class="fg"><label class="fl">Trạng thái</label><select id="sact" class="fc"><option value="true" ${s?.active!==false?'selected':''}>✅ Đang làm việc</option><option value="false" ${s?.active===false?'selected':''}>❌ Nghỉ việc</option></select></div>
    </div>
  </div>
  <div class="modal-ft"><button class="btn btn-gh" onclick="closeModal()">${t('cancel')}</button><button class="btn btn-p" onclick="saveStaff(${id||'null'})">${t('save')}</button></div>`);
}
function saveStaff(id){
  const name=document.getElementById('sn').value.trim();
  if(!name){sErr('sn','Họ tên không được để trống');return}
  const data={name,phone:document.getElementById('sp').value,email:document.getElementById('se').value,role:document.getElementById('sr').value,shift:document.getElementById('ss').value,salary:parseInt(document.getElementById('sal').value)||7000000,active:document.getElementById('sact').value==='true'};
  if(id&&id!=='null')StaffDB.update(id,data);else StaffDB.add(data);
  closeModal();showToast(`✅ Đã ${id&&id!=='null'?'cập nhật':'thêm'} nhân viên!`,'s');navigate('staff');
}
function delStaff(id){const s=StaffDB.getAll().find(x=>x.id===parseInt(id));if(s&&confirm(`Xóa nhân viên "${s.name}"?`)){StaffDB.delete(id);showToast('Đã xóa nhân viên!','s');navigate('staff')}}

/* ── 16. INVENTORY ── */
function renderInventory(){
  const inv=InventoryDB.getAll();
  const low=inv.filter(i=>i.quantity<=i.minQty);
  return`
  <div class="ph d-flex jb ac fw gap2">
    <div><h2>📦 ${t('inventory')}</h2><p>${inv.length} loại nguyên liệu</p></div>
    <button class="btn btn-p" onclick="openInvForm()">➕ ${t('addInventory')}</button>
  </div>
  ${low.length>0?`<div class="inv-alert">⚠️ <b>${low.length} nguyên liệu</b> sắp hết hàng: ${low.map(i=>`${i.name} (còn ${i.quantity} ${i.unit})`).join(', ')}<button class="btn btn-sm btn-d" style="margin-left:auto" onclick="filterLowStock()">Lọc</button></div>`:''}
  <div class="card">
    <div class="tbl-wrap"><table><thead><tr><th>${t('ingredient')}</th><th>${t('quantity')}</th><th>${t('unit')}</th><th>${t('minQty')}</th><th>${t('costPrice')}</th><th>${t('supplier')}</th><th>Trạng thái</th><th>${t('action')}</th></tr></thead>
    <tbody id="invBody2">${renderInvRows(inv)}</tbody></table></div>
  </div>`;
}
function renderInvRows(inv){
  return inv.map(i=>`<tr><td class="fw7">${i.name}</td><td class="fw8 ${i.quantity<=i.minQty?'cer':''}">${i.quantity}</td><td style="color:var(--mu)">${i.unit}</td><td>${i.minQty}</td><td>${V(i.cost)}</td><td style="font-size:.78rem">${i.supplier}</td><td>${i.quantity<=i.minQty?`<span class="badge b-low">⚠️ Thấp</span>`:`<span class="badge b-ok">✅ Đủ</span>`}</td><td><div class="d-flex gap1"><button class="btn btn-sm btn-gh" onclick="openInvForm(${i.id})">✏️</button><button class="btn btn-sm btn-s" onclick="openAdjust(${i.id})">📦</button><button class="btn btn-sm btn-d" onclick="delInv(${i.id})">🗑️</button></div></td></tr>`).join('');
}
function filterLowStock(){const inv=InventoryDB.getAll().filter(i=>i.quantity<=i.minQty);const tb=document.getElementById('invBody2');if(tb)tb.innerHTML=renderInvRows(inv)}
function openInvForm(id){
  const item=id?InventoryDB.getAll().find(x=>x.id===parseInt(id)):null;
  showModal(`
  <div class="modal-hd"><h3>${item?'✏️ Chỉnh sửa':'➕ '+t('addInventory')}</h3><button class="modal-cl" onclick="closeModal()">✕</button></div>
  <div class="modal-body">
    <div class="fr">
      <div class="fg"><label class="fl">${t('ingredient')} <span class="req">*</span></label><input id="in_name" class="fc" value="${item?.name||''}"><span class="em" id="in_name_e"></span></div>
      <div class="fg"><label class="fl">${t('unit')}</label><select id="in_unit" class="fc"><option value="kg" ${item?.unit==='kg'?'selected':''}>kg</option><option value="lít" ${item?.unit==='lít'?'selected':''}>lít</option><option value="cái" ${item?.unit==='cái'?'selected':''}>cái</option><option value="hộp" ${item?.unit==='hộp'?'selected':''}>hộp</option><option value="gói" ${item?.unit==='gói'?'selected':''}>gói</option></select></div>
    </div>
    <div class="fr">
      <div class="fg"><label class="fl">${t('quantity')}</label><input id="in_qty" type="number" class="fc" value="${item?.quantity||0}" min="0"></div>
      <div class="fg"><label class="fl">${t('minQty')}</label><input id="in_min" type="number" class="fc" value="${item?.minQty||5}" min="0"></div>
    </div>
    <div class="fr">
      <div class="fg"><label class="fl">${t('costPrice')} (đ)</label><input id="in_cost" type="number" class="fc" value="${item?.cost||0}" min="0"></div>
      <div class="fg"><label class="fl">${t('supplier')}</label><input id="in_sup" class="fc" value="${item?.supplier||''}"></div>
    </div>
  </div>
  <div class="modal-ft"><button class="btn btn-gh" onclick="closeModal()">${t('cancel')}</button><button class="btn btn-p" onclick="saveInv(${id||'null'})">${t('save')}</button></div>`);
}
function saveInv(id){
  const name=document.getElementById('in_name').value.trim();
  if(!name){sErr('in_name','Tên không được để trống');return}
  const data={name,unit:document.getElementById('in_unit').value,quantity:document.getElementById('in_qty').value,minQty:document.getElementById('in_min').value,cost:document.getElementById('in_cost').value,supplier:document.getElementById('in_sup').value};
  if(id&&id!=='null')InventoryDB.update(id,data);else InventoryDB.add(data);
  closeModal();showToast('✅ Đã lưu!','s');navigate('inventory');
}
function openAdjust(id){
  const item=InventoryDB.getAll().find(x=>x.id===parseInt(id));if(!item)return;
  showModal(`
  <div class="modal-hd"><h3>📦 ${t('adjustQty')} – ${item.name}</h3><button class="modal-cl" onclick="closeModal()">✕</button></div>
  <div class="modal-body">
    <div style="background:var(--cr);border-radius:var(--rs);padding:1rem;margin-bottom:1rem;text-align:center"><div style="font-size:.8rem;color:var(--mu)">Tồn kho hiện tại</div><div style="font-size:2rem;font-weight:800;color:var(--cdk)">${item.quantity} <span style="font-size:1rem;color:var(--mu)">${item.unit}</span></div></div>
    <div class="fg"><label class="fl">Điều chỉnh (+ nhập thêm, − xuất kho)</label><input id="adj_qty" type="number" class="fc" placeholder="VD: +10 hoặc -5"></div>
    <div class="fg"><label class="fl">Lý do</label><input id="adj_note" class="fc" placeholder="Nhập thêm hàng / Hao hụt..."></div>
  </div>
  <div class="modal-ft"><button class="btn btn-gh" onclick="closeModal()">${t('cancel')}</button><button class="btn btn-p" onclick="doAdjust(${id})">${t('confirm')}</button></div>`);
}
function doAdjust(id){
  const delta=parseInt(document.getElementById('adj_qty').value)||0;
  if(delta===0){showToast('Nhập số lượng điều chỉnh!','w');return}
  const item=InventoryDB.getAll().find(x=>x.id===parseInt(id));
  if(!item)return;
  const newQty=Math.max(0,item.quantity+delta);
  InventoryDB.update(id,{...item,quantity:newQty});
  closeModal();showToast(`✅ Đã điều chỉnh: ${item.quantity} → ${newQty} ${item.unit}`,'s');navigate('inventory');
}
function delInv(id){const i=InventoryDB.getAll().find(x=>x.id===parseInt(id));if(i&&confirm(`Xóa "${i.name}"?`)){InventoryDB.delete(id);showToast('Đã xóa!','s');navigate('inventory')}}

/* ── 17. STATISTICS ── */
function renderStats(){
  const orders=OrderDB.getCompleted();
  const total=orders.reduce((s,o)=>s+o.total,0);
  const avg=orders.length?Math.round(total/orders.length):0;
  const soldMap={};orders.forEach(o=>o.items.forEach(it=>{soldMap[it.name]=(soldMap[it.name]||0)+it.qty}));
  const top5=Object.entries(soldMap).sort((a,b)=>b[1]-a[1]).slice(0,5);
  const payMap={cash:0,momo:0,bank:0};orders.forEach(o=>payMap[o.payment]=(payMap[o.payment]||0)+o.total);
  const last7=getLast7Rev();
  // Doanh thu theo tháng (6 tháng gần nhất)
  const now=new Date();
  const months=[];const mLabels=[];const mValues=[];
  for(let i=5;i>=0;i--){const d=new Date(now.getFullYear(),now.getMonth()-i,1);months.push(`${d.getFullYear()}-${d.getMonth()}`);mLabels.push(`T${d.getMonth()+1}`)}
  months.forEach((m,idx)=>{const rev=orders.filter(o=>{const d=new Date(o.time);return`${d.getFullYear()}-${d.getMonth()}`===m}).reduce((s,o)=>s+o.total,0);mValues.push(rev)});
  setTimeout(()=>{
    try{
      if(typeof Chart==='undefined')return;
      const c1=document.getElementById('sc1');if(c1)new Chart(c1,{type:'bar',data:{labels:mLabels,datasets:[{label:'Doanh thu',data:mValues,backgroundColor:'rgba(111,78,55,.7)',borderColor:'#6F4E37',borderWidth:2,borderRadius:6}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}});
      const c2=document.getElementById('sc2');if(c2)new Chart(c2,{type:'line',data:{labels:last7.labels,datasets:[{label:'7 ngày',data:last7.values,borderColor:'#6F4E37',backgroundColor:'rgba(111,78,55,.1)',fill:true,tension:.4,pointBackgroundColor:'#6F4E37'}]},options:{responsive:true,plugins:{legend:{display:false}}}});
      const c3=document.getElementById('sc3');if(c3)new Chart(c3,{type:'doughnut',data:{labels:['Tiền mặt','MoMo','Chuyển khoản'],datasets:[{data:[payMap.cash,payMap.momo,payMap.bank],backgroundColor:['#6F4E37','#ae2070','#2980b9'],borderWidth:2}]},options:{responsive:true,plugins:{legend:{position:'bottom'}}}});
    }catch(e){}
  },120);
  return`
  <div class="ph"><h2>📈 ${t('stats')}</h2><p>Phân tích doanh thu và hiệu suất kinh doanh</p></div>
  <div class="stats-grid">
    <div class="stat-card"><div class="stat-ico">📋</div><div class="stat-val">${orders.length}</div><div class="stat-lbl">${t('totalOrders')}</div></div>
    <div class="stat-card"><div class="stat-ico">💰</div><div class="stat-val">${V(total)}</div><div class="stat-lbl">${t('totalRevenue')}</div></div>
    <div class="stat-card"><div class="stat-ico">🧾</div><div class="stat-val">${V(avg)}</div><div class="stat-lbl">${t('avgOrder')}</div></div>
    <div class="stat-card"><div class="stat-ico">☕</div><div class="stat-val">${Object.values(soldMap).reduce((a,b)=>a+b,0)}</div><div class="stat-lbl">Tổng ly đã bán</div></div>
  </div>
  <div class="chart-grid">
    <div class="chart-card"><h3>📊 Doanh thu theo tháng (6 tháng gần nhất)</h3><canvas id="sc1" height="200"></canvas></div>
    <div class="chart-card"><h3>🍩 Theo phương thức TT</h3><canvas id="sc3" height="200"></canvas></div>
  </div>
  <div style="display:grid;grid-template-columns:2fr 1fr;gap:1rem">
    <div class="chart-card"><h3>📈 Doanh thu 7 ngày gần đây</h3><canvas id="sc2" height="180"></canvas></div>
    <div class="card">
      <div class="card-hd"><h3>🏆 ${t('topProducts')}</h3></div>
      <div class="card-body">
        ${top5.map(([name,qty],i)=>`
          <div class="d-flex ac gap1" style="margin-bottom:.7rem">
            <span style="width:22px;height:22px;border-radius:50%;background:${['var(--g)','#c0c0c0','#cd7f32','var(--bd)','var(--bd)'][i]};display:flex;align-items:center;justify-content:center;font-size:.68rem;font-weight:800;color:${i<3?'var(--cdk)':'var(--mu)'};flex-shrink:0">${i+1}</span>
            <div style="flex:1">
              <div style="font-size:.8rem;font-weight:700;color:var(--cdk)">${name}</div>
              <div style="height:3px;background:var(--bd);border-radius:2px;margin-top:2px"><div style="height:100%;border-radius:2px;background:linear-gradient(to right,var(--c),var(--g));width:${top5[0]?Math.round(qty/top5[0][1]*100):0}%"></div></div>
            </div>
            <span class="fw8 cc" style="font-size:.78rem">${qty}ly</span>
          </div>`).join('')}
      </div>
    </div>
  </div>`;
}

/* ── 18. LOGIN ── */
function initLogin(){
  document.getElementById('loginForm').addEventListener('submit',function(e){
    e.preventDefault();
    const u=document.getElementById('lu').value.trim();
    const p=document.getElementById('lp').value;
    let ok=true;
    if(!u){sErr('lu','Vui lòng nhập tên đăng nhập');ok=false}else cErr('lu');
    if(!p){sErr('lp','Vui lòng nhập mật khẩu');ok=false}else cErr('lp');
    if(!ok)return;
    const user=Auth.login(u,p);
    if(user){
      showApp(true);
      buildSidebar();buildTopbar();Cart.badge();
      const firstPage=Auth.can('dashboard')?'dashboard':'pos';
      navigate(firstPage);
      showToast(`☕ ${t('welcome')}, ${user.name}!`,'s');
    }else{sErr('lp','Sai tên đăng nhập hoặc mật khẩu!');showToast('Thông tin không chính xác!','e')}
  });
}

/* ── 19. INIT ── */
window.addEventListener('load',()=>{
  lang=S.get('lang')||'vi';
  document.querySelectorAll('.lang-btn').forEach(b=>b.classList.toggle('active',b.dataset.lang===lang));
  // Khởi tạo mock data
  ProductDB.getAll();OrderDB.getAll();StaffDB.getAll();InventoryDB.getAll();
  // Kiểm tra session
  if(Auth.is()){
    showApp(true);buildSidebar();buildTopbar();Cart.badge();
    navigate(Auth.can('dashboard')?'dashboard':'pos');
  }else{showApp(false)}
  initLogin();
  // Init charts sau khi render dashboard
  document.getElementById('main').addEventListener('DOMNodeInserted',()=>{if(document.getElementById('revChart'))setTimeout(initCharts,50)});
});
// Override để init charts khi vào dashboard
const _origRender=renderPage;
function renderPage(page){
  const fn={dashboard:renderDashboard,pos:renderPOS,menu:renderMenu,orders:renderOrders,invoices:renderInvoices,staff:renderStaff,inventory:renderInventory,stats:renderStats};
  const main=document.getElementById('main');
  main.innerHTML=(fn[page]||renderDashboard)();
  if(page==='dashboard'||page==='stats')setTimeout(initCharts,80);
  window.scrollTo(0,0);
}